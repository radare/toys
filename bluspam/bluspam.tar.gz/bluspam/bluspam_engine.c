inline int bluspam_engine_system(const char *str)
{
	return system(str);
}

inline void bluspam_engine_exit(int ret)
{
	exit(ret);
}

inline unsigned char bluspam_engine_char0(const char *str)
{
	return str[0];
}
