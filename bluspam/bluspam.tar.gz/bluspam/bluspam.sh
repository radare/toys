#!/bin/sh
#
# bluspam shellscript launcher
#

cd ##PREFIX##/libexec/bluspam && ./bluspam
